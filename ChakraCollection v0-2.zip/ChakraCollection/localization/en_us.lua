return {
    --[[
    descriptions = {
        Edtion = {
            e_chak_ignited = {
                name = "Ignited",
                text = {
                    'Retriggers itself, {C:green,s:0.8}1 in 6',
                    'chance this card is {C:red}destroyed',
                    'at end of round'
                }
            }
        }
    },
    ]]
    misc = {
        dictionary = {
            k_chak_chakra_pack = "Chakra Pack",
            k_chak_chakra_mega = "Chakra Pack",
        }
    },
    Other = {
        chak_ethereal = {
            name = "Ethereal",
            text = {
                'Disables itself when',
                'you enter the shop,',
                'always has {C:orange}$0{} sell value'
            }
        }
    }
}