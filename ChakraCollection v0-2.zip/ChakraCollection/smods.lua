-- Steamodded is not necessary. This just adds a bit of compatibility.

if SMODS.Atlas then
    SMODS.Atlas({
        key = "modicon",
        path = "modicon.png",
        px = 34,
        py = 34
    })
end